Mercenaries Updater.exe is  used for updating Mercenaries Mod.
Use it everytime new path is deployed on servers. 
Report any issue on website.



