Run Updater->Mercenaries Updater.exe
Click "Update" button.

Do it everytime there is new version.